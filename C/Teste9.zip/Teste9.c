#include <stdio.h>
int main(){
int vetoru, vetorv, i=1,  soma1, soma2;
printf("Informe o valor do vetor U: ");
scanf("%i", &vetoru);
printf("Informe o valor do vetor V: ");
scanf("%i", &vetorv);

soma1 = vetoru * vetorv;
soma2 = vetoru + vetorv * i;
printf("O resultado e: %i", soma1);
printf("O resultado e: %\n", soma2);
printf("Darlan nao conseguir fazer o programa pelo fato de nao ter intendido a materia e o que foi pedido, se puder depois dar uma aula explicando essa parte de vetores aplicando em problemas matematicos agradeço!");
  return ;
}
